let menuicn = document.querySelector(".menuicn"); 
let nav = document.querySelector(".navcontainer"); 

menuicn.addEvenstListener("click", () => { 
	nav.classList.toggle("navclose"); 
})